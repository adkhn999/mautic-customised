<?php
/*
 * @copyright   2018 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace Mautic\LeadBundle\Segment\Exception;

use Doctrine\DBAL\Query\QueryException;

/**
 * Class SegmentQueryException.
 */
class SegmentQueryException extends QueryException
{
}
